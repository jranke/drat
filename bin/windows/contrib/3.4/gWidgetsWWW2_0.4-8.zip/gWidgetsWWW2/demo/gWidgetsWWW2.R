load_app(system.file("demo/demo.R", package="gWidgetsWWW2"), "Demo")

  

