## ---- include = FALSE----------------------------------------------------
library(knitr)
opts_chunk$set(tidy = FALSE, cache = FALSE)

## ---- eval = FALSE-------------------------------------------------------
#  library(gmkin)

## ---- eval = FALSE-------------------------------------------------------
#  gmkin()

## ---- eval = FALSE-------------------------------------------------------
#  write.table(schaefer07_complex_case, sep = ",", dec = ".",
#              row.names = FALSE, quote = FALSE,
#              file = "schaefer07.csv")

## ---- eval = FALSE-------------------------------------------------------
#  > Ordinary least squares optimisation
#  Sum of squared residuals at call 1: 2388.077
#  Sum of squared residuals at call 3: 2388.077
#  Sum of squared residuals at call 4: 247.1962
#  Sum of squared residuals at call 7: 200.6791
#  Sum of squared residuals at call 10: 197.7231
#  Sum of squared residuals at call 11: 197.0872
#  Sum of squared residuals at call 14: 196.535
#  Sum of squared residuals at call 15: 196.535
#  Sum of squared residuals at call 16: 196.535
#  Sum of squared residuals at call 17: 196.5334
#  Sum of squared residuals at call 20: 196.5334
#  Sum of squared residuals at call 25: 196.5334
#  Negative log-likelihood at call 31: 26.64668
#  Optimisation successfully terminated.

