mds <- mkinds$new("FOCUS A", FOCUS_2006_A)
