caffeine <- chent$new("caffeine")
print(caffeine)
plot(caffeine)
