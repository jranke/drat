atr <- pai$new("atrazine")
print(atr)
