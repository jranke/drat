results[[1]]
results_pfm[[1]]

r1 <- results[[2]]$periods$flux
r2 <- results_pfm[[2]]$periods$flux
r1 - r2
expect_equal(r1, r2, tol = 1e-6, scale = 1)

results[[3]]
results_pfm[[3]]
