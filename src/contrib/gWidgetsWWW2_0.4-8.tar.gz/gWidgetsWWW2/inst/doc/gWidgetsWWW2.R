### R code from vignette source 'gWidgetsWWW2.Rnw'

###################################################
### code chunk number 1: gWidgetsWWW2.Rnw:109-111
###################################################
require("gWidgetsWWW2")
suppressMessages(gwindow())


###################################################
### code chunk number 2: gWidgetsWWW2.Rnw:115-120
###################################################
w <- gwindow("simple GUI with one button", visible=FALSE)
g <- ggroup(cont = w)
b <- gbutton("click me", cont = g, handler = function(h,...) {
  gmessage("hello world", parent = b)
})


###################################################
### code chunk number 3: gWidgetsWWW2.Rnw:130-132
###################################################
out <- w$dump()
head(out)


###################################################
### code chunk number 4: gWidgetsWWW2.Rnw:145-146 (eval = FALSE)
###################################################
## load_app("hello.R", app_name="HelloApp")


###################################################
### code chunk number 5: gWidgetsWWW2.Rnw:267-273
###################################################
w <- gwindow("simple GUI with one button", visible=FALSE)
g <- ggroup(cont = w, horizontal=FALSE, use.scrollwindow=TRUE)
button_group <- ggroup(cont=g, horizontal=TRUE) ## opposite to g
b <- gbutton("click me", cont = button_group, handler = function(h,...) {
  gmessage("hello world", parent = b)
})


###################################################
### code chunk number 6: gWidgetsWWW2.Rnw:431-432 (eval = FALSE)
###################################################
## w$toplevel


###################################################
### code chunk number 7: gWidgetsWWW2.Rnw:436-437
###################################################
identical(w$toplevel, g$toplevel)


###################################################
### code chunk number 8: gWidgetsWWW2.Rnw:443-444 (eval = FALSE)
###################################################
## w$toplevel$the_request$path_info()


###################################################
### code chunk number 9: add_js_queue
###################################################
w$add_js_queue("alert('hello world');")


