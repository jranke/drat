w <- gwindow("Test app")
g <- glabel("Test label", cont = w)
