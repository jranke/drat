library(testthat)
library(pfm)

test_check("pfm")
