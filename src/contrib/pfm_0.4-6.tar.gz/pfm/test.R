library(pfm)
library(R6)
library(readr)
source("R/TOXSWA_cwa.R")
test <- read.TOXSWA_cwa("32.out", basedir = "/home/jranke/git/pfm/")
test_old <- read.TOXSWA_cwa("32_old.out", basedir = "/home/jranke/git/pfm/")
TOXSWA_cwa$debug("initialize")
test <- TOXSWA_cwa$new("32.out", basedir = "/home/jranke/git/pfm/")

