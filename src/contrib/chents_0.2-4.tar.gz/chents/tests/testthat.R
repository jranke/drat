library(testthat)
library(chents)

test_check("chents")
