oct <- chent$new("1-octanol", smiles = "CCCCCCCCO")
print(oct)
plot(oct)
