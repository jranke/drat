library(testthat)
library(mkin)

test_check("mkin")
