library(testthat)
library(saemix)

test_check("saemix")
