###########################  Model Comparison with BIC or AIC 	#############################

#' Model comparison with information criteria (AIC, BIC).
#' 
#' A specific penalty is used for BIC (BIC.cov) when the compared models have in common the 
#' structural model and the covariance structure for the random effects (see Delattre et al., 2014). 
#' 
#' Note that the comparison between two or more models will only be valid if they are 
#' fitted to the same dataset.
#' 
#' @param mod.list A list of two or more objects returned by the \code{\link{saemix}} function
#' @param method The method used for computing the likelihood : "is" (Importance Sampling), 
#' "ll" (Linearisation) or "gq" (Gaussian quadrature). Default "is"
#' @return A matrix of information criteria is returned, with at least two columns containing respectively
#' AIC and BIC values for each of the compared models. When the models have in common the structural model 
#' and the covariance structure for the random effects, the matrix includes an additional column with BIC.cov 
#' values that are more appropriate when the comparison only concerns the covariates.
#' @author Emmanuelle Comets <emmanuelle.comets@@inserm.fr>, Maud Delattre
#' @references Delattre, M., Lavielle, M. and Poursat, M.A. (2014) A note on BIC in mixed effects models. 
#' Electronic Journal of Statistics 8(1) p. 456-475
#' @keywords model comparison, AIC, BIC
#' @examples 
#' data(theo.saemix)
#' 
#' saemix.data<-saemixData(name.data=theo.saemix,header=TRUE,sep=" ",na=NA,
#'   name.group=c("Id"),name.predictors=c("Dose","Time"),
#'   name.response=c("Concentration"),name.covariates=c("Weight","Sex"),
#'   units=list(x="hr",y="mg/L",covariates=c("kg","-")), name.X="Time")
#' 
#' # Definition of models to be compared
#' model1cpt<-function(psi,id,xidep) { 
#'    dose<-xidep[,1]
#'    tim<-xidep[,2]  
#'    ka<-psi[id,1]
#'    V<-psi[id,2]
#'    CL<-psi[id,3]
#'    k<-CL/V
#'    ypred<-dose*ka/(V*(ka-k))*(exp(-k*tim)-exp(-ka*tim))
#'    return(ypred)
#' }
#' # Model with one covariate
#' saemix.model1<-saemixModel(model=model1cpt,modeltype="structural", 
#'                           description="One-compartment model with first-order absorption",
#'                           psi0=matrix(c(1.,20,0.5,0.1,0,-0.01),ncol=3,byrow=TRUE, dimnames=list(NULL, c("ka","V","CL"))), 
#'                           transform.par=c(1,1,1),covariate.model=matrix(c(0,0,1,0,0,0),ncol=3,byrow=TRUE))
#' # Model with two covariates       
#' saemix.model2<-saemixModel(model=model1cpt,modeltype="structural", 
#'                            description="One-compartment model with first-order absorption", 
#'                            psi0=matrix(c(1.,20,0.5,0.1,0,-0.01),ncol=3,byrow=TRUE, dimnames=list(NULL, c("ka","V","CL"))), 
#'                            transform.par=c(1,1,1),covariate.model=matrix(c(0,0,1,0,1,0),ncol=3,byrow=TRUE))
#' # Model with three covariates
#' saemix.model3<-saemixModel(model=model1cpt,modeltype="structural", 
#'                            description="One-compartment model with first-order absorption", 
#'                            psi0=matrix(c(1.,20,0.5,0.1,0,-0.01),ncol=3,byrow=TRUE, dimnames=list(NULL, c("ka","V","CL"))), 
#'                            transform.par=c(1,1,1),covariate.model=matrix(c(1,0,1,0,1,0),ncol=3,byrow=TRUE))
#' 
#' # Running the main algorithm to estimate the population parameters                                                     
#' saemix.options<-list(seed=632545,save=FALSE,save.graphs=FALSE)
#' saemix.fit1<-saemix(saemix.model1,saemix.data,saemix.options)
#' saemix.fit2<-saemix(saemix.model2,saemix.data,saemix.options)
#' saemix.fit3<-saemix(saemix.model3,saemix.data,saemix.options)
#' 
#' # Model comparison
#' 
#' comparison.res <- compare.saemix(list(saemix.fit1, saemix.fit2,saemix.fit3))
#' 
#' @export compare.saemix


compare.saemix<-function(mod.list,...) {
  
  if (!is.list(mod.list)){
    stop("'mod.list' must be a list.")
  } else {
    if (length(mod.list)<=1){
      stop("'compare.saemix' requires at least two models.") 
    } else {
      list.class <- sapply(mod.list, class)
      if (!all(list.class=="SaemixObject")) {
        stop("All inputs should have class 'SaemixObject'.")
      }
    }
  }
  
  nb.mod <- length(mod.list)
  
  
  args1<-match.call(expand.dots=TRUE)
  i1<-match("method",names(args1))
  
  if(!is.na(i1)) {
    str1<-as.character(args1[[i1]])
    if(str1 %in% c("is","lin","gq")) {
      method<-str1
    } else method<-"is"
  } else method<-"is"
  
  
  for (k in 1:nb.mod){
    if(method=="is" & length(mod.list[[k]]@results@ll.is)==0) {
      namObj<-deparse(substitute(mod.list[[k]]))
      mod.list[[k]]<-llis.saemix(mod.list[[k]])
      assign(namObj,mod.list[[k]],envir=parent.frame())
    }
  }
  
  for (k in 1:nb.mod){
    if(method=="gq" & length(mod.list[[k]]@results@ll.gq)==0) {
      namObj<-deparse(substitute(mod.list[[k]]))
      mod.list[[k]]<-llgq.saemix(mod.list[[k]])
      assign(namObj,mod.list[[k]],envir=parent.frame())
    }    
  }
  
  
  for (k in 1:nb.mod){
    if(method=="lin" & length(mod.list[[k]]@results@ll.lin)==0) {
      namObj<-deparse(substitute(mod.list[[k]]))
      mod.list[[k]]<-fim.saemix(mod.list[[k]])
      assign(namObj,mod.list[[k]],envir=parent.frame())
    }
  }
  
  
  if (method=="is"){
    
    info <- matrix(0,nb.mod,2)
    rownames(info) <- as.character(seq(1,nb.mod))
    colnames(info) <- c("AIC","BIC")
    
    str.model <- list()
    cov.model <- list()
    
    # Comparison of datasets : if models are estimated on different datasets, comparison does 
    # not make sense. 
    
    same.data <- rep(NA,(nb.mod-1))
    
    for (k in 2:nb.mod){
      same.data[k-1] <- identical(mod.list[[1]]@data,mod.list[[k]]@data)
    }
    
    
    if ("FALSE" %in% same.data){
      stop('Compared models should be fitted on the same data.')
    } else{
      # Comparison of the statistical models : BIC.covariate does only make sense if model type,
      # structural model (and residual model if appropriate), and covariance structure for the random 
      # effects are the same
      
      for (k  in 1:nb.mod){
        info[k,] <- c(mod.list[[k]]@results@aic.is,mod.list[[k]]@results@bic.is)
      }
      
      same.model.type <- rep(NA,(nb.mod-1))
      same.str.model <- rep(NA,(nb.mod-1))
      
      for (k in 2:nb.mod){
        same.model.type[k-1] <- identical(mod.list[[1]]@model@modeltype,mod.list[[k]]@model@modeltype)
        same.str.model[k-1] <- identical(mod.list[[1]]@model@model,mod.list[[k]]@model@model)
      }
      
      if (!("FALSE" %in% same.model.type)){
        
        if (!("FALSE" %in% same.str.model)){
          
          same.cov.model <- rep(NA,(nb.mod-1))
          
          for (k in 2:nb.mod){
            same.cov.model[k-1] <- identical(mod.list[[1]]@model@covariance.model,mod.list[[k]]@model@covariance.model)
          }
          
          if (mod.list[[1]]@model@modeltype == "structural"){
            
            same.res.model <- rep(NA,(nb.mod-1))
            
            
            
            for (k in 2:nb.mod){
              same.res.model[k-1] <- identical(mod.list[[1]]@model@error.model,mod.list[[k]]@model@error.model)
            }
            
            if ((!("FALSE" %in% same.cov.model)) && (!("FALSE" %in% same.res.model))){
              bic.cov <- rep(NA,nb.mod)
              for (k in 1:nb.mod){
                bic.cov[k] <- mod.list[[k]]@results@bic.covariate.is
              }
              info <- cbind(info, bic.cov)
              colnames(info) <- c("AIC","BIC","BIC.cov")
              
            }
            
          } else {
            if (!("FALSE" %in% same.cov.model)){
              bic.cov <- rep(NA,nb.mod)
              for (k in 1:nb.mod){
                bic.cov[k] <- mod.list[[k]]@results@bic.covariate.is
              }
              info <- cbind(info, bic.cov)
              colnames(info) <- c("AIC","BIC","BIC.cov")
            }
          }
        }
        
      }
      cat("Likelihoods computed by importance sampling \n")
    }
  }
  
  if (method=="lin"){
    
    info <- matrix(0,nb.mod,2)
    rownames(info) <- as.character(seq(1,nb.mod))
    colnames(info) <- c("AIC","BIC")
    
    str.model <- list()
    cov.model <- list()
    
    # Comparison of datasets : if models are estimated on different datasets, comparison does 
    # not make sense. 
    
    same.data <- rep(NA,(nb.mod-1))
    
    for (k in 2:nb.mod){
      same.data[k-1] <- identical(mod.list[[1]]@data,mod.list[[k]]@data)
    }
    
    
    if ("FALSE" %in% same.data){
      stop('Compared models should be fitted on the same data.')
    } else{
      # Comparison of the statistical models : BIC.covariate does only make sense if model type,
      # structural model (and) residual model if appropriate), and covariance structure for the random 
      # effects are the same
      
      for (k  in 1:nb.mod){
        info[k,] <- c(mod.list[[k]]@results@aic.lin,mod.list[[k]]@results@bic.lin)
      }
      
      same.model.type <- rep(NA,(nb.mod-1))
      same.str.model <- rep(NA,(nb.mod-1))
      
      for (k in 2:nb.mod){
        same.model.type[k-1] <- identical(mod.list[[1]]@model@modeltype,mod.list[[k]]@model@modeltype)
        same.str.model[k-1] <- identical(mod.list[[1]]@model@model,mod.list[[k]]@model@model)
      }
      
      if (!("FALSE" %in% same.model.type)){
        
        if (!("FALSE" %in% same.str.model)){
          
          same.cov.model <- rep(NA,(nb.mod-1))
          
          for (k in 2:nb.mod){
            same.cov.model[k-1] <- identical(mod.list[[1]]@model@covariance.model,mod.list[[k]]@model@covariance.model)
          }
          
          if (mod.list[[1]]@model@modeltype == "structural"){
            
            same.res.model <- rep(NA,(nb.mod-1))
            
            
            
            for (k in 2:nb.mod){
              same.res.model[k-1] <- identical(mod.list[[1]]@model@error.model,mod.list[[k]]@model@error.model)
            }
            
            if ((!("FALSE" %in% same.cov.model)) && (!("FALSE" %in% same.res.model))){
              bic.cov <- rep(NA,nb.mod)
              for (k in 1:nb.mod){
                bic.cov[k] <- mod.list[[k]]@results@bic.covariate.lin
              }
              info <- cbind(info, bic.cov)
              colnames(info) <- c("AIC","BIC","BIC.cov")
              
            }
            
          } else {
            warning('Linearisation is not appropriate for computing likelihoods in discrete models.')
            if (!("FALSE" %in% same.cov.model)){
              bic.cov <- rep(NA,nb.mod)
              for (k in 1:nb.mod){
                bic.cov[k] <- mod.list[[k]]@results@bic.covariate.lin
              }
              info <- cbind(info, bic.cov)
              colnames(info) <- c("AIC","BIC","BIC.cov")
            }
          }
        }
        
      }
      
    
      
      cat("Likelihoods computed by linearisation \n")
    }
  }
  
  if (method=="gq"){
    
    info <- matrix(0,nb.mod,2)
    rownames(info) <- as.character(seq(1,nb.mod))
    colnames(info) <- c("AIC","BIC")
    
    str.model <- list()
    cov.model <- list()
    
    # Comparison of datasets : if models are estimated on different datasets, comparison does 
    # not make sense. 
    
    same.data <- rep(NA,(nb.mod-1))
    
    for (k in 2:nb.mod){
      same.data[k-1] <- identical(mod.list[[1]]@data,mod.list[[k]]@data)
    }
    
    
    if ("FALSE" %in% same.data){
      stop('Compared models should be fitted on the same data.')
    } else{
      # Comparison of the statistical models : BIC.covariate does only make sense if model type,
      # structural model (and residual model if appropriate), and covariance structure for the random 
      # effects are the same
      
      for (k  in 1:nb.mod){
        info[k,] <- c(mod.list[[k]]@results@aic.gq,mod.list[[k]]@results@bic.gq)
      }
      
      same.model.type <- rep(NA,(nb.mod-1))
      same.str.model <- rep(NA,(nb.mod-1))
      
      for (k in 2:nb.mod){
        same.model.type[k-1] <- identical(mod.list[[1]]@model@modeltype,mod.list[[k]]@model@modeltype)
        same.str.model[k-1] <- identical(mod.list[[1]]@model@model,mod.list[[k]]@model@model)
      }
      
      if (!("FALSE" %in% same.model.type)){
        
        if (!("FALSE" %in% same.str.model)){
          
          same.cov.model <- rep(NA,(nb.mod-1))
          
          for (k in 2:nb.mod){
            same.cov.model[k-1] <- identical(mod.list[[1]]@model@covariance.model,mod.list[[k]]@model@covariance.model)
          }
          
          if (mod.list[[1]]@model@modeltype == "structural"){
            
            same.res.model <- rep(NA,(nb.mod-1))
            
            
            
            for (k in 2:nb.mod){
              same.res.model[k-1] <- identical(mod.list[[1]]@model@error.model,mod.list[[k]]@model@error.model)
            }
            
            if ((!("FALSE" %in% same.cov.model)) && (!("FALSE" %in% same.res.model))){
              bic.cov <- rep(NA,nb.mod)
              for (k in 1:nb.mod){
                bic.cov[k] <- mod.list[[k]]@results@bic.covariate.gq
              }
              info <- cbind(info, bic.cov)
              colnames(info) <- c("AIC","BIC","BIC.cov")
              
            }
            
          } else {
            if (!("FALSE" %in% same.cov.model)){
              bic.cov <- rep(NA,nb.mod)
              for (k in 1:nb.mod){
                bic.cov[k] <- mod.list[[k]]@results@bic.covariate.gq
              }
              info <- cbind(info, bic.cov)
              colnames(info) <- c("AIC","BIC","BIC.cov")
            }
          }
        }
        
      }
      
      cat("Likelihoods computed by Gaussian quadrature \n")
    }
  }
  return(info)
}