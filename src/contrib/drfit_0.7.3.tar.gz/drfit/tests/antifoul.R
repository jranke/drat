library(drfit)
data(antifoul)
rantifoul <- drfit(antifoul)
print(rantifoul,digits=5)
