library(drfit)
data(IM1xVibrio)
rIM1xVibrio <- drfit(IM1xVibrio)
print(rIM1xVibrio,digits=4)
