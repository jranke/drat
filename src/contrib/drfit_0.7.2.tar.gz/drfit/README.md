# drfit

[![](https://www.r-pkg.org/badges/version/drfit)](https://cran.r-project.org/package=drfit)

Static documentation of this R package can be found at
https://pkgdown.jrwb.de/drfit
