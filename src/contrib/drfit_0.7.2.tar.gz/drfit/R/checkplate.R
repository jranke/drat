checkplate <- function(id, db = c("cytotox", "enzymes"))
{
  checkexperiment(id, db = db)
}
