mkinplot <- function(fit, ...)
{
  plot(fit, ...)
}
